﻿using System;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using sieberti_i_dejman.Services;
using sieberti_i_dejman.ViewModels;

namespace sieberti_i_dejman.ViewModels
{
    public partial class MainVMAlt : ObservableObject
    {
        [ObservableProperty]
        private object? _currentView;

        public RecipesVMAlt RecipesVM { get; }
        public PlannerVMAlt PlannerVM { get; }
        public ShopListVMAlt ShoppingVM { get; }

        public MainVMAlt()
        {
            var dataService = new DataServiceAlt();

            RecipesVM = new RecipesVMAlt(dataService);
            PlannerVM = new PlannerVMAlt(dataService, RecipesVM);
            ShoppingVM = new ShopListVMAlt(PlannerVM);

            PlannerVM.PropertyChanged += (s, e) => ShoppingVM.RefreshCommand.Execute(null);
            CurrentView = RecipesVM;
        }

        [RelayCommand]
        private void ShowRecipes() => CurrentView = RecipesVM;

        [RelayCommand]
        private void ShowPlanner() => CurrentView = PlannerVM;

        [RelayCommand]
        private void ShowShoppingList()
        {
            ShoppingVM.RefreshCommand.Execute(null);  // DZIAŁA ZAWSZE
            CurrentView = ShoppingVM;
        }
    }
}