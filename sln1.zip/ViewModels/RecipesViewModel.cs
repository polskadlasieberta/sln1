﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using sieberti_i_dejman.Models;
using sieberti_i_dejman.Services;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;

namespace sieberti_i_dejman.ViewModels
{
    public partial class RecipesVMAlt : ObservableObject
    {
        private readonly DataServiceAlt _dataService;

        public ObservableCollection<RecipeAlt> Recipes { get; } = new();

        private RecipeAlt? _selectedRecipe;
        public RecipeAlt? SelectedRecipe
        {
            get => _selectedRecipe;
            set => SetProperty(ref _selectedRecipe, value);
        }

        private string _searchText = "";
        public string SearchText
        {
            get => _searchText;
            set
            {
                if (SetProperty(ref _searchText, value))
                {
                    _ = FilterRecipesAsync(value);
                }
            }
        }

        public RecipesVMAlt(DataServiceAlt dataService)
        {
            _dataService = dataService;
            _ = LoadRecipesAsync(); 
        }

        [RelayCommand]
        private async Task LoadRecipesAsync()
        {
            var list = await _dataService.LoadRecipesAsync();
            Recipes.Clear();
            foreach (var r in list)
                Recipes.Add(r);
        }

        [RelayCommand]
        private async Task AddOrUpdateRecipe()
        {
            if (SelectedRecipe is null) return;

            var existing = Recipes.FirstOrDefault(r => r.Id == SelectedRecipe.Id);
            if (existing is null)
                Recipes.Add(SelectedRecipe);
            else
            {
                var index = Recipes.IndexOf(existing);
                Recipes[index] = SelectedRecipe;
            }

            await _dataService.SaveRecipesAsync(Recipes.ToList());
            await LoadRecipesAsync();
        }

        [RelayCommand]
        private async Task DeleteRecipe()
        {
            if (SelectedRecipe is null) return;

            Recipes.Remove(SelectedRecipe);
            await _dataService.SaveRecipesAsync(Recipes.ToList());
            SelectedRecipe = null;
        }
        private async Task FilterRecipesAsync(string search)
        {
            var all = await _dataService.LoadRecipesAsync();

            var filtered = string.IsNullOrWhiteSpace(search)
                ? all
                : all.Where(r => r.Name.Contains(search, System.StringComparison.OrdinalIgnoreCase))
                     .ToList();

            Recipes.Clear();
            foreach (var r in filtered)
                Recipes.Add(r);
        }
    }
}