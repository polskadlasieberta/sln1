﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using sieberti_i_dejman.Models;
using sieberti_i_dejman.Services;
using System;
using System.Threading.Tasks;

namespace sieberti_i_dejman.ViewModels
{
    public partial class PlannerVMAlt : ObservableObject
    {
        private readonly DataServiceAlt _dataService;

        private WeeklyPlanAlt _plan = new();
        public WeeklyPlanAlt Plan
        {
            get => _plan;
            set => SetProperty(ref _plan, value);
        }

        public RecipesVMAlt RecipesVM { get; }

        private RecipeAlt? _selectedRecipeToAssign;
        public RecipeAlt? SelectedRecipeToAssign
        {
            get => _selectedRecipeToAssign;
            set => SetProperty(ref _selectedRecipeToAssign, value);
        }

        public PlannerVMAlt(DataServiceAlt dataService, RecipesVMAlt recipesVM)
        {
            _dataService = dataService;
            RecipesVM = recipesVM;
            _ = LoadPlanAsync(); 
        }

        [RelayCommand]
        private async Task LoadPlanAsync()
        {
            Plan = await _dataService.LoadPlanAsync();
        }

        [RelayCommand]
        private async Task AssignRecipe(DayOfWeek day)
        {
            if (SelectedRecipeToAssign is null) return;
            Plan.Meals[day] = SelectedRecipeToAssign;
            await _dataService.SavePlanAsync(Plan);
        }

        [RelayCommand]
        private async Task ClearDay(DayOfWeek day)
        {
            Plan.Meals[day] = null;
            await _dataService.SavePlanAsync(Plan);
        }
    }
}