﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sieberti_i_dejman.Models
{
    public class IngredientAlt
    {
        public string Name { get; set; } = string.Empty;
        public string Amount { get; set; } = string.Empty; 
    }
}
